import {html, nothing} from 'lit';
import './default.css';

// A sparkline: one SVG image named by the label and a sentence of the data.
// The inside is markup set as the svg element's innerHTML (a property, so
// lit writes no part markers there and a first-paint snapshot is stable).
// A page's own colour (the color setting) is a variable in a style.

const px = (value) => `${Math.round(value * 10) / 10}`;

function marksMarkup(g) {
  if (!g) return '';
  if (g.empty) return `<line class="sf-chart-sparkline-empty" x1="0" x2="${px(g.width)}" y1="${px(g.height / 2)}" y2="${px(g.height / 2)}"/>`;
  let out = '';
  if (g.bars) {
    for (const bar of g.bars) {
      out += `<rect class="sf-chart-sparkline-bar${bar.marked ? ' sf-chart-sparkline-bar--mark' : ''}" x="${px(bar.x)}" y="${px(bar.y)}" width="${px(bar.width)}" height="${px(bar.height)}"/>`;
    }
    return out;
  }
  if (g.area) out += `<path class="sf-chart-sparkline-area" d="${g.area}"/>`;
  out += `<path class="sf-chart-sparkline-line" d="${g.d}"/>`;
  for (const [x, y] of g.marks) out += `<circle class="sf-chart-sparkline-mark" cx="${px(x)}" cy="${px(y)}" r="${px(g.radius)}"/>`;
  return out;
}

export function renderChartSparklineTemplate(context) {
  const {state, geometry: g, name} = context;
  const size = String(context.size).replace('/', '-');
  return html`
    <span class=${['sf-chart-sparkline', `sf-chart-sparkline--size-${size}`, `sf-chart-sparkline--${state}`, `sf-chart-sparkline--${context.shape}`, context.rootClass].filter(Boolean).join(' ')}
          style=${context.paint ? `--sf-chart-sparkline--own: ${context.paint}` : nothing}
          role="img" aria-label=${name} aria-busy=${state === 'loading' ? 'true' : 'false'}>
      <svg class="sf-chart-sparkline-svg" aria-hidden="true" focusable="false"
           width=${g ? g.width : 0} height=${g ? g.height : 0} viewBox=${g ? `0 0 ${g.width} ${g.height}` : '0 0 0 0'}
           .innerHTML=${marksMarkup(g)}></svg>
    </span>
  `;
}
